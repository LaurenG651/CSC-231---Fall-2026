from stack import Stack
stack = Stack()

file = open('undo/undo1.txt', 'r')
text = file.read()

for character in text:
    if character == '<':
        stack.pop()
    else:
        stack.push(character)

print(stack)

file.close()


#For file2


file = open('undo/undo2.txt', 'r')
text = file.read()

for character in text:
    if character == '<':
        stack.pop()
    else:
        stack.push(character)

print(stack)

file.close()


#For file3


file = open('undo/undo3.txt', 'r')
text = file.read()

for character in text:
    if character == '<':
        stack.pop()
    else:
        stack.push(character)

print(stack)

file.close()

