#Lauren Garland
#CSC 231 section 001

def compute_stats(file):
    F = open(file, 'r')

    numbers = []
    count = 0
    total = 0

    for number in F:
        number = int(number)
        numbers.append(number)
        count += 1
        total += number

        if count == 1:
            minimum = number
            maximum = number
        elif number < minimum:
            minimum = number
        elif number > maximum:
            maximum = number

    numbers.sort()

    if count % 2 == 1:
        median = numbers[count // 2]
    else:
        median = (numbers[count // 2] + numbers[(count // 2) - 1]) / 2

    print(f'Count: {count}')
    print(f'Average: {total / count}')
    print(f'Min: {minimum}')
    print(f'Max: {maximum}')
    print(f'Median: {median}')

    F.close()


if __name__ == "__main__":
    
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import ComputeStatsTests
    import sys
    suite = ComputeStatsTests(sys.modules[__name__])
    suite.test_01_numbers("numbers.txt")
    suite.test_02_numbers2("numbers2.txt")
    suite.test_03_numbers6("numbers6.txt")
    suite.test_04_numbers7("numbers7.txt")
    
