# Lauren Garland
# CSC 231, section 001

class Node:
    def __init__(self,data):
        self.data = data
        self.next = None

    def __str__(self):
        return f"Node(data={self.data})"

class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def is_empty(self):
        return self.size == 0

    def add(self,item):
        new_node = Node(item)

        if self.is_empty():
            self.tail = new_node

        new_node.next = self.head
        self.head = new_node
        self.size += 1

    def __iter__(self):
        current = self.head
        while current is not None:
            yield current
            current = current.next

    def append(self,item):
        new_node = Node(item)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node

        else:
            self.tail.next = new_node
            self.tail = new_node

        self.size += 1

    def pop(self, pos=None):
        if self.is_empty():
            raise IndexError("Cannot pop from an empty list")

        if pos is not None and not isinstance(pos, int):
            raise TypeError("Position must be an integer")

        if pos is None:
            pos = self.size - 1

        if pos < 0 or pos >= self.size:
            raise IndexError("Position out of range")

        if pos == 0:
            removed = self.head
            self.head = self.head.next

            if self.size == 1:
                self.tail = None

        else:
            current = self.head

            for i in range(pos - 1):
                current = current.next

            removed = current.next
            current.next = removed.next

            if removed == self.tail:
                self.tail = current

        self.size -= 1
        return removed.data

    def search (self,item):
        for node in self:
            if node.data == item:
                return True
        return False 

    def remove(self, item):
        current = self.head
        previous = None

        while current is not None and current.data != item:
            previous = current
            current = current.next

        if current is None:
            raise ValueError("Item not found in list")

        if previous is None:
            self.head = current.next
        else:
            previous.next = current.next

        if current == self.tail:
            self.tail = previous

        self.size -= 1
        
        

if __name__ == '__main__': 
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.
    from tests_ll import LLTests
    import sys
    suite = LLTests(sys.modules[__name__])
    suite.test_01_node_basic()
    suite.test_02_ll_init_is_empty()
    suite.test_03_add_basic()
    suite.test_04_append_basic()
    suite.test_05_append_to_empty()
    suite.test_06_iter_basic()
    suite.test_07_search()
    suite.test_08_remove_head_tail_middle()
    suite.test_09_remove_only_element_and_missing()
    suite.test_10_pop_default_and_indices()
    suite.test_11_pop_errors_and_types()
