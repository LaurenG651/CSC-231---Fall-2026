# Lauren Garland
# CSC 231, section 001

class Node:
    def __init__(self,data):
        self.data = data
        self.next = None
        self.prev = None

    def __str__(self):
        return str(self.data)

class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def is_empty(self):
        return self.size == 0

    def add(self,item):
        new_node = Node(item)

        if self.is_empty():
            self.tail = new_node

        else:
            self.head.prev = new_node
            new_node.next = self.head
            
        self.head = new_node
        self.size += 1

    def __iter__(self):
        current = self.head
        while current is not None:
            yield current
            current = current.next

    def append(self,item):
        new_node = Node(item)

        if self.is_empty():
            self.head = new_node
            self.tail = new_node

        else:
            self.tail.next = new_node
            new_node.prev = self.tail
            self.tail = new_node

        self.size += 1

    def pop(self, pos=None):
        if pos is None:
            pos = self.size - 1

        if pos < 0 or pos >= self.size:
            raise IndexError("Position out of range")

        current = self.head

        for i in range(pos):
            current = current.next

        if current.prev is None:
            self.head = current.next

        else:
            current.prev.next = current.next

        if current.next is None:
            self.tail = current.prev

        else:
            current.next.prev = current.prev

        self.size -= 1
        return current.data

    def search (self,item):
        for node in self:
            if node.data == item:
                return True
        return False 

    
    def remove(self, item):
        current = self.head

        while current is not None and current.data != item:
            current = current.next

        if current.prev is None:
            self.head = current.next

        else:
            current.prev.next = current.next

        if current.next is None:
            self.tail = current.prev

        else:
            current.next.prev = current.prev

        self.size -= 1

        
if __name__ == '__main__': 
    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.
    from tests_ll import DLLTests
    import sys
    suite = DLLTests(sys.modules[__name__])
    suite.test_01_node_basic()
    suite.test_02_dll_init_is_empty()
    suite.test_03_add_basic_and_links()
    suite.test_04_append_basic_and_links()
    suite.test_05_append_to_empty()
    suite.test_06_iter_basic()
    suite.test_07_search()
    suite.test_08_remove_head_tail_middle_links()
    suite.test_09_remove_only_element_and_missing()
    suite.test_10_pop_tail_head_middle()
    suite.test_11_pop_errors_and_types()
