#Lauren Garland
#CSC 231, Section 001

class Fraction:

    def __init__(self, numerator, denominator):
        self.numerator = numerator
        self.setDenominator(denominator)

    def __str__(self):
        return str(self.numerator) + "/" + str(self.denominator)

    def getNumerator(self):
        return self.numerator

    def getDenominator(self):
        return self.denominator

    def setNumerator(self, value):
        self.numerator = value

    def setDenominator(self, value):
        if value <= 0:
            raise ValueError()
        self.denominator = value

    def reduce(self):
        gcd = self.__calcGCD()
        self.numerator = self.numerator // gcd
        self.denominator = self.denominator // gcd
        return self

    def __calcGCD(self):
        m = abs(self.numerator)
        n = self.denominator

        while m % n != 0:
            oldm = m
            oldn = n
            m = oldn
            n = oldm % oldn

        return n

    def __neg__(self):
        return Fraction(-self.numerator, self.denominator)

    def __add__(self, other):
        numerator = self.numerator * other.denominator
        numerator = numerator + other.numerator * self.denominator

        denominator = self.denominator * other.denominator

        answer = Fraction(numerator, denominator)
        return answer.reduce()

    def __sub__(self, other):
        numerator = self.numerator * other.denominator
        numerator = numerator - other.numerator * self.denominator

        denominator = self.denominator * other.denominator

        answer = Fraction(numerator, denominator)
        return answer.reduce()

    def __mul__(self, other):
        numerator = self.numerator * other.numerator
        denominator = self.denominator * other.denominator

        answer = Fraction(numerator, denominator)
        return answer.reduce()

    def __truediv__(self, other):
        numerator = self.numerator * other.denominator
        denominator = self.denominator * other.numerator

        answer = Fraction(numerator, denominator)
        return answer.reduce()

    def __eq__(self, other):
        return self.numerator * other.denominator == \
               other.numerator * self.denominator

    def __ne__(self, other):
        return not self == other

    def __lt__(self, other):
        return self.numerator * other.denominator < \
               other.numerator * self.denominator

    def __le__(self, other):
        return self < other or self == other

    def __gt__(self, other):
        return self.numerator * other.denominator > \
               other.numerator * self.denominator

    def __ge__(self, other):
        return self > other or self == other


if __name__ == "__main__":

    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import FractionTests
    import sys
    suite = FractionTests(sys.modules[__name__])
    suite.test_01_constructor_basic()
    suite.test_02_constructor_negative_numerator()
    suite.test_03_constructor_denom_zero_error()
    suite.test_04_constructor_denom_negative_error()
    suite.test_05_reduce_basic()
    suite.test_06_reduce_negative()
    suite.test_07_addition_simple()
    suite.test_08_subtraction()
    suite.test_09_multiplication()
    suite.test_10_division()
    suite.test_11_equality_true_unreduced()
    suite.test_12_equality_false()
    suite.test_13_greater_than()
    suite.test_14_less_than()
    suite.test_15_comparison_equal()
