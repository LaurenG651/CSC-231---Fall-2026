from fraction import Fraction


def main():

    fraction1 = Fraction(4, 8)
    fraction2 = Fraction(1, 4)

    print("Starting fraction 1:", fraction1)
    print("Starting fraction 2:", fraction2)

    print("The numerator of 4/8 is:", fraction1.getNumerator())
    print("The denominator of 4/8 is:", fraction1.getDenominator())

    fraction1.setNumerator(6)
    print("After changing the numerator of fraction 1 to 6:", fraction1)

    fraction1.setDenominator(8)
    print("After changing the denominator of fraction 1 to 8:", fraction1)

    fraction1 = Fraction(4, 8)
    print("4/8 reduced to lowest terms:", fraction1.reduce())

    print("The negative of 1/4 is:", -fraction2)

    print("4/8 + 1/4 =", fraction1 + fraction2)
    print("4/8 - 1/4 =", fraction1 - fraction2)
    print("4/8 * 1/4 =", fraction1 * fraction2)
    print("4/8 / 1/4 =", fraction1 / fraction2)

    equivalent1 = Fraction(1, 2)
    equivalent2 = Fraction(2, 4)

    print("Does 1/2 equal 2/4?", equivalent1 == equivalent2)
    print("Does 4/8 equal 1/4?", fraction1 == fraction2)
    print("Is 4/8 less than 1/4?", fraction1 < fraction2)
    print("Is 4/8 less than or equal to 1/4?", fraction1 <= fraction2)
    print("Is 4/8 greater than 1/4?", fraction1 > fraction2)
    print("Is 4/8 greater than or equal to 1/4?", fraction1 >= fraction2)

    try:
        Fraction(3, 0)
    except ValueError:
        print("Trying to create 3/0 correctly gives a ValueError.")


main()
