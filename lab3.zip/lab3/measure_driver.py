#Lauren Garland
#CSC 231, Section 001

from measure import FootMeasure

#Creating Objects
fm1 = FootMeasure()
fm2 = FootMeasure(feet=5)
fm3 = FootMeasure(feet=5, inches=8)
fm4 = FootMeasure(inches=68)

#Testing Printing Objects 
print(fm1)
print(fm2)
print(fm3)
print(fm4)

#Testing Adding Objects 
fm5 = fm2 + fm3
print(fm5)

#Testing ==
print(fm2 == fm3)

#Testing !-
print(fm2 != fm3)

#Testing <
print(fm2 < fm3)

#Testing <=
print(fm2 <= fm3)

#Testing >
print(fm2 > fm3)

#Testing >=
print(fm2 >= fm3)
