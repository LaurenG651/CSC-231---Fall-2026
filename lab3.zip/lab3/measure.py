#Lauren Garland
#CSC 231, Section 001

class FootMeasure:
    def __init__(self, feet=0, inches=0):
        self.inches = feet * 12 + inches

    def __str__(self):
        feet = self.inches // 12
        inches = self.inches % 12
        return f"{feet} ft. {inches} ins."

    def __add__(self, other):
        return FootMeasure(inches=self.inches + other.inches)

    def __eq__(self, other):
        return self.inches == other.inches

    def __ne__(self, other):
        return self.inches != other.inches

    def __lt__(self, other):
        return self.inches < other.inches

    def __le__(self, other):
        return self.inches <= other.inches

    def __gt__(self, other):
        return self.inches > other.inches

    def __ge__(self, other):
        return self.inches >= other.inches

if __name__ == "__main__":
    # You may add code below this line to help you test.


    # You may comment out the calls to the test_xxx() functions to reduce the amount printed to the screen as you work.
    # Uncomment them when you are ready to test.

    from tests import FootMeasureTests
    import sys
    suite = FootMeasureTests(sys.modules[__name__])
    suite.test_01_zero_measure()
    suite.test_02_simple_measure()
    suite.test_03_inches_only()
    suite.test_04_normalization()
    suite.test_05_addition_simple()
    suite.test_06_addition_with_carry()
    suite.test_07_equality_true()
    suite.test_08_equality_false()
    suite.test_09_greater_than()
    suite.test_10_less_than()
    suite.test_11_greater_equal_and_less_equal()
